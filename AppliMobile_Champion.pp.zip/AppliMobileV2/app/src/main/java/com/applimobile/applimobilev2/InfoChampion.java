package com.applimobile.applimobilev2;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import net.rithms.riot.api.RiotApi;
import net.rithms.riot.api.RiotApiException;
import net.rithms.riot.constant.Region;
import net.rithms.riot.constant.staticdata.ChampData;
import net.rithms.riot.dto.Static.Champion;
import net.rithms.riot.dto.Static.ChampionSpell;
import net.rithms.riot.dto.Static.Passive;
import net.rithms.riot.dto.Static.Stats;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Permet l'affichage des informations concernant un champion
 * <p>
 * Created by lecorre on 25/02/2016.
 */
public class InfoChampion extends Activity {
	public static final String EXTRA_TAB_SKINS = "com.applimobile.applimobilev2.EXTRA_TAB_SKINS";
	public static final String EXTRA_CHAMPION_NAME = "com.applimobile.applimobilev2.EXTRA_CHAMPION_NAME";
	RiotApi api = new RiotApi("93f6127b-6ca0-4c0e-9aea-e0832feec88b");

	Champion champion;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.infochampion_layout);

		Intent intent = getIntent();
		int idChamp = intent.getIntExtra(ListChampions.EXTRA_IDCHAMP, -1);

		//RECUPERATION DES VIEWS
		ImageView imgV = (ImageView) findViewById(R.id.imagechampion);
		TextView textVChamp = (TextView) findViewById(R.id.textViewChamp);
		TextView textVPassif = (TextView) findViewById(R.id.textViewPassif);
		TextView textVPassifLong = (TextView) findViewById(R.id.textViewPassifLong);

		TextView textVSpell1 = (TextView) findViewById(R.id.textViewSpell1);
		TextView textVSpell1Long = (TextView) findViewById(R.id.textViewSpell1Long);

		TextView textVSpell2 = (TextView) findViewById(R.id.textViewSpell2);
		TextView textVSpell2Long = (TextView) findViewById(R.id.textViewSpell2Long);

		TextView textVSpell3 = (TextView) findViewById(R.id.textViewSpell3);
		TextView textVSpell3Long = (TextView) findViewById(R.id.textViewSpell3Long);

		TextView textVSpell4 = (TextView) findViewById(R.id.textViewSpell4);
		TextView textVSpell4Long = (TextView) findViewById(R.id.textViewSpell4Long);

		ImageView imVPassif = (ImageView) findViewById(R.id.imageViewPassif);
		ImageView imVSpell1 = (ImageView) findViewById(R.id.imageViewSpell1);
		ImageView imVSpell2 = (ImageView) findViewById(R.id.imageViewSpell2);
		ImageView imVSpell3 = (ImageView) findViewById(R.id.imageViewSpell3);
		ImageView imVSpell4 = (ImageView) findViewById(R.id.imageViewSpell4);

		TextView textVArmor = (TextView) findViewById(R.id.textViewArmor);
		TextView textVArmorLvl = (TextView) findViewById(R.id.textViewArmorLvl);
		TextView textVMR = (TextView) findViewById(R.id.textViewMR);
		TextView textVMRLvl = (TextView) findViewById(R.id.textViewMRLvl);
		TextView textVHP = (TextView) findViewById(R.id.textViewHP);
		TextView textVHPLvl = (TextView) findViewById(R.id.textViewHPLvl);
		TextView textVAD = (TextView) findViewById(R.id.textViewAD);
		TextView textVADLvl = (TextView) findViewById(R.id.textViewADLvl);
		TextView textVRange = (TextView) findViewById(R.id.textViewRange);
		// FIN RECUPERATION DES VIEWS

		// récuperation d'un champion par son Id
		champion = getChampById(idChamp);

		// récuperation des informations concernant le champion
		List<ChampionSpell> championSpell = champion.getSpells();
		String championLore = champion.getLore();
		Passive championPassive = champion.getPassive();

		if (championPassive == null) {
			Toast toast = Toast.makeText(getApplicationContext(), "null", Toast.LENGTH_SHORT);
			toast.show();
		}

		//RECUPERATION DES IMAGES
		String full = champion.getImage().getFull();
		//String full = champion.getName() + ".png";
		String url = "http://ddragon.leagueoflegends.com/cdn/6.4.1/img/champion/" + full;
		Drawable dTemp = loadImg(url, full);
		imgV.setImageDrawable(dTemp);

		textVChamp.setText(champion.getName());

		String urlPassive = "http://ddragon.leagueoflegends.com/cdn/6.4.1/img/passive/" + championPassive.getImage().getFull();
		Drawable dTempPassive = loadImg(urlPassive, championPassive.getImage().getFull());
		imVPassif.setImageDrawable(dTempPassive);


		textVPassif.setText(championPassive.getName());
		textVPassifLong.setText(championPassive.getDescription());

		String urlSpell = "http://ddragon.leagueoflegends.com/cdn/6.4.1/img/spell/";
		int cpt = 0;
		for (ChampionSpell s : championSpell) {
			switch (cpt) {
				case 0:
					textVSpell1.setText(s.getName());
					textVSpell1Long.setText(s.getDescription());
					String urlSpell1 = urlSpell + s.getImage().getFull();
					Drawable dTemp1 = loadImg(urlSpell1, s.getImage().getFull());
					imVSpell1.setImageDrawable(dTemp1);
					break;

				case 1:
					textVSpell2.setText(s.getName());
					textVSpell2Long.setText(s.getDescription());
					String urlSpell2 = urlSpell + s.getImage().getFull();
					Drawable dTemp2 = loadImg(urlSpell2, s.getImage().getFull());
					imVSpell2.setImageDrawable(dTemp2);
					break;

				case 2:
					textVSpell3.setText(s.getName());
					textVSpell3Long.setText(s.getDescription());
					String urlSpell3 = urlSpell + s.getImage().getFull();
					Drawable dTemp3 = loadImg(urlSpell3, s.getImage().getFull());
					imVSpell3.setImageDrawable(dTemp3);
					break;

				case 3:
					textVSpell4.setText(s.getName());
					textVSpell4Long.setText(s.getDescription());
					String urlSpell4 = urlSpell + s.getImage().getFull();
					Drawable dTemp4 = loadImg(urlSpell4, s.getImage().getFull());
					imVSpell4.setImageDrawable(dTemp4);
					break;

			}
			cpt++;
		}
		//FIN RECUPERATION DES IMAGES

		//INITIALISATION DES CHAINES DE CARACTERES
		Stats stats = champion.getStats();
		String attackDamage = getResources().getString(R.string.ad) + Double.toString(stats.getAttackDamage());
		String attackDamagePerLevel = getResources().getString(R.string.ad_lvl)+ Double.toString(stats.getAttackDamagePerLevel());
		String armor = getResources().getString(R.string.armor) + Double.toString(stats.getArmor());
		String armorPerLevel = getResources().getString(R.string.armor_lvl)+ Double.toString(stats.getArmorPerLevel());
		String magicResist = getResources().getString(R.string.magic_resis)+ Double.toString(stats.getSpellBlock());
		String magicResistPerLevel = getResources().getString(R.string.mr_lvl)+ Double.toString(stats.getSpellBlockPerLevel());
		String hp = getResources().getString(R.string.hp)+ Double.toString(stats.getHp());
		String hpPerLevel = getResources().getString(R.string.hp_lvl)+ Double.toString(stats.getHpPerLevel());
		String range = getResources().getString(R.string.Range)+ Double.toString(stats.getAttackRange());

		//MODIFICATION DES TEXTVIEWS
		textVAD.setText(attackDamage);
		textVADLvl.setText(attackDamagePerLevel);
		textVArmor.setText(armor);
		textVArmorLvl.setText(armorPerLevel);
		textVMR.setText(magicResist);
		textVMRLvl.setText(magicResistPerLevel);
		textVHP.setText(hp);
		textVHPLvl.setText(hpPerLevel);
		textVRange.setText(range);


	}


	/**
	 * Récupère les images sur un site
	 * @param url l'URL du site
	 * @param name un mon
	 * @return Un Drawable representant l'image
	 */
	public static Drawable loadImg(String url, String name) {
		try {
			InputStream is = (InputStream) new URL(url).getContent();
			Drawable d = Drawable.createFromStream(is, name);
			return d;
		} catch (Exception e) {
			Log.i("oui", "image non recue");
			return null;
		}
	}

	/**
	 * Récupere un champion par un Id
	 * @param idChamp Id du champion a récuperer
	 * @return Le champion récupéré
	 */
	public static Champion getChampById(int idChamp) {
		Champion champ = null;

		RiotApi api = new RiotApi("93f6127b-6ca0-4c0e-9aea-e0832feec88b");

		try {
			api.setRegion(Region.EUW);

			champ = api.getDataChampion(idChamp, "fr_FR", null, ChampData.ALL);

		} catch (RiotApiException e) {
			Log.i("RiotApiPb", "Erreur liée a l'API de riot");
		}
		return champ;
	}


	/**
	 * Affiche les splashs
	 *
	 * @param view une vue
	 */
	public void splash(View view) {
		Log.i("oui", "debut splash");
		Intent intent = new Intent(this, SplashChamp.class);

		ArrayList<Integer> tabSkins = new ArrayList<>();

		for (int i = 0; i < champion.getSkins().size(); i++) {
			tabSkins.add(champion.getSkins().get(i).getNum());
		}

		intent.putIntegerArrayListExtra(EXTRA_TAB_SKINS, tabSkins);


		String championName = (champion.getImage().getFull()).substring(0, champion.getImage().getFull().length() - 4);
		intent.putExtra(EXTRA_CHAMPION_NAME, championName);

		startActivity(intent);
	}
}