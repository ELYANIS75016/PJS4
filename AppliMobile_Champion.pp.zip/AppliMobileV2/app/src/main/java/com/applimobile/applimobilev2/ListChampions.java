package com.applimobile.applimobilev2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import net.rithms.riot.api.RiotApi;
import net.rithms.riot.api.RiotApiException;
import net.rithms.riot.constant.Region;
import net.rithms.riot.dto.Static.Champion;
import net.rithms.riot.dto.Static.ChampionList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Permet la gestion de l'activité de la Liste des champions
 *
 * Created by Thomas on 26/02/2016.
 */
public class ListChampions extends Activity {

	static final RiotApi api = new RiotApi("93f6127b-6ca0-4c0e-9aea-e0832feec88b");

	ListChampions listechampionclass = this;
	public static final String EXTRA_IDCHAMP = "com.projet.applimobile.applimobile.EXTRA_IDCHAMP";
	List<String> tabChamp = new ArrayList<String>();


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listchampions_layout);

		ListView mListView = (ListView) findViewById(R.id.listView);
		remplissageListe(mListView);
	}

	/**
	 * @param listV la liste à remplir
	 */
	public void remplissageListe(ListView listV) {
		//Champion champ = null;
		ChampionList champs;

		try {
			api.setRegion(Region.EUW);

			champs = api.getDataChampionList();
			final Map<String, Champion> mapChamp = champs.getData();
			Set<String> listeClef = mapChamp.keySet();
			final List<String> listClefTriee = new ArrayList<String>(listeClef);

			Collections.sort(listClefTriee);

			for (String s : listClefTriee) {
				Champion champTemp = mapChamp.get(s);
				tabChamp.add(champTemp.getName());
			}


			ArrayAdapter<String> adapter = new ArrayAdapter<String>(ListChampions.this, android.R.layout.simple_list_item_1, tabChamp);
			listV.setAdapter(adapter);

			listV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

					// String nomChampion = "Cliqué sur : " + String.valueOf(adapterView.getItemAtPosition(position));

					// Toast.makeText(Listchampions.this, nomChampion, Toast.LENGTH_SHORT).show();
					Intent intent = new Intent(listechampionclass, InfoChampion.class);
					String keyTemp = listClefTriee.get(position);
					int idTemp = mapChamp.get(keyTemp).getId();
					intent.putExtra(EXTRA_IDCHAMP, idTemp);

					startActivity(intent);

				}
			});


		} catch (RiotApiException e) {
			Log.i("RiotApiPb", "Erreur liée a l'API de riot");
		}

	}

	/**
	 * pour rechercher un champion par le nom en EditText
	 * @param view une Vue
	 */
	public void rechercheChampion(View view) {
		EditText editTextNameChamp = (EditText) findViewById(R.id.editTextRechercheChampion);
		String nameChamp = editTextNameChamp.getText().toString();
		ChampionList champs;

		try {
			api.setRegion(Region.EUW);
			champs = api.getDataChampionList();
			final Map<String, Champion> mapChamp = champs.getData();

			Champion champTemp = mapChamp.get(nameChamp);

			if (!(champTemp == null)) {
				int idTemp = champTemp.getId();
				Intent intent = new Intent(listechampionclass, InfoChampion.class);
				intent.putExtra(EXTRA_IDCHAMP, idTemp);
				startActivity(intent);
			}else{
				Toast.makeText(this, "Le Champion n'existe pas", Toast.LENGTH_SHORT).show();
			}

		} catch (RiotApiException e) {
			Log.i("RiotApiPb", "Erreur liée a l'API de riot");
		}
	}
}
